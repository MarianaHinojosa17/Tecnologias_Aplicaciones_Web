
<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso PHP |  Bienvenidos</title>
    <link rel="stylesheet" href="./css/foundation.css" />
    <script src="./js/vendor/modernizr.js"></script>
  </head>
  <body>
    
    <?php require_once('header.php'); ?>



  <center>    
    <div class="row">
 
      <div class="">
        <br><br><br>
        <h1>Tpo de Deportistas</h1>
        <br>
         
         
        <div class="section-container tabs" data-section>
          <section class="section">
            <div class="content" data-slug="panel1">
              <div class="row">
              </div>
               <!-- Se crean los dos botones para poder accesar a los dos ejercicios, el de el contado de los usuarios y el de el control de los deportistas -->
              <br><br>
              <a href="./futbolistas.php" class="button">Futbolistas</a>
              <br><br>
              <a href="./basquetbolistas.php" class="button">Basquetbolistas</a>
              <br><br><br><br>
            </div>
          </section>
        </div>
        
      </div>

    </div>
  </center>  

    <?php require_once('footer.php'); ?>

