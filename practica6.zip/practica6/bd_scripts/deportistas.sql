-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 14-05-2018 a las 06:35:08
-- Versión del servidor: 5.6.38
-- Versión de PHP: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `deportistas`
--
CREATE DATABASE IF NOT EXISTS `deportistas` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `deportistas`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `basquetbol`
--

CREATE TABLE `basquetbol` (
  `id` int(11) NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `posicion` varchar(30) NOT NULL,
  `carrera` varchar(30) NOT NULL,
  `correo` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `basquetbol`
--

INSERT INTO `basquetbol` (`id`, `nombre`, `posicion`, `carrera`, `correo`) VALUES
(10, 'Sergio Perez Pi', 'base', 'ITI', 'sergio@correo.com'),
(12, 'Edwyn Bobadilla', 'escolta', 'IM', 'edwyn@correo.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `futbol`
--

CREATE TABLE `futbol` (
  `id` int(11) NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `posicion` varchar(30) NOT NULL,
  `carrera` varchar(30) NOT NULL,
  `correo` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `futbol`
--

INSERT INTO `futbol` (`id`, `nombre`, `posicion`, `carrera`, `correo`) VALUES
(1, 'Miguel Angel Rdz', 'central', 'ITI', 'miguel@correo.com'),
(10, 'Fher Fco Torres', 'portero', 'ITI', 'fher@correo.com'),
(19, 'Antonio Molina', 'defensa', 'ISA', 'toño1@correo.com');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `futbol`
--
ALTER TABLE `futbol`
  ADD PRIMARY KEY (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
