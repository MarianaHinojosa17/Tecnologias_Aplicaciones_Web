<?php

//se manda llamar el archivo donde se tienen las funciones
require_once('database_utilities.php');


?>
<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso PHP |  Bienvenidos</title>
    <link rel="stylesheet" href="./css/foundation.css" />
    <script src="./js/vendor/modernizr.js"></script>
  </head>
  <body>
    
    <?php require_once('header.php'); ?>

     
    <div class="row">
 
      <div class="large-9 columns">
        <br><br><br>
        <h2>Contando Datos</h2>
        <br><br>
          
        <div class="section-container tabs" data-section>
          <section class="section">
            <div class="content" data-slug="panel1">
              <div class="row">
              </div>
              
              <table>
                <thead>
                  <tr>
                    <th width="200">Usuarios</th>
                    <th width="250">Tipos</th>
                    <th width="250">Status</th>
                    <th width="250">Accesos</th>
                    <th width="250">Usuarios Activos</th>
                    <th width="250">Usuarios Inactivos</th>
                  </tr>
                </thead>
                <tbody>
                  <!--Se imprime en una tabla los datos que se trajeron con la consulta almacenada en el archivo de database_utilities, imprimiendo las variavles con los resultados-->
                  <tr>
                    <td><?php echo $total_users?></td>
                    <td><?php echo $total_users_type?></td>
                    <td><?php echo $total_status?></td>
                    <td><?php echo $total_logged?></td>
                    <td><?php echo $total_active_users?></td>
                    <td><?php echo $total_inactive_users?></td>
                  </tr>
                </tbody>


              </table>

              <br><br><br>
              <h2>Tabla Usuarios</h2>
              <br><br>  

              <table>
                
                <thead>
                  <tr>
                    <th width="200">ID</th>
                    <th width="250">E-mail</th>
                    <th width="250">Password</th>
                    <th width="250">Status</th>
                    <th width="250">Tipo de usuario</th>
                  </tr>
                </thead>

                <tbody>
                  <!-- Se crea un ciclo para que este imprimiendo en una tabla los datos de todos los usuarios realizados, obteniendo esos datos en el archivo de database_utilities -->
                  <?php
                      for ($i=0; $i < $total_users ; $i++) 
                      {
                      ?>
                      <tr> 
                        <td><?php echo $user[$i]['id']?></td>
                        <td><?php echo $user[$i]['email'];?></td>
                        <td><?php echo $user[$i]['password'];?></td>
                        <td><?php echo $user_status[$i]['name'];?></td>
                        <td><?php echo $user_type[$i]['name'];?></td>
                      </tr>
                  <?php
                      }
                      ?>
                </tbody>

              </table>

              <br><br><br>
              <h2>Tabla Sesion de Usuarios</h2>
              <br><br>  

              <table>
                
                <thead>
                  <tr>
                    <th width="200">ID</th>
                    <th width="250">Fecha de Sesion</th>
                    <th width="250">Usuario</th>
                  </tr>
                </thead>

                <tbody>
                  <!-- Se crea un ciclo para que este imprimiendo en una tabla los datos de todos las sesiones registradas, obteniendo esos datos en el archivo de database_utilities -->
                  <?php
                      for ($i=0; $i < $total_logged ; $i++) 
                      {
                      ?>
                      <tr> 
                        <td><?php echo $log[$i]['id']?></td>
                        <td><?php echo $log[$i]['date_logged_in'];?></td>
                        <td><?php echo $user_log[$i]['email'];?></td>
                      </tr>
                  <?php
                      }
                      ?>
                </tbody>

              </table>

              <br><br><br>
              <h2>Tabla Tipo de Usuarios</h2>
              <br><br>  

              <table>
                
                <thead>
                  <tr>
                    <th width="200">ID</th>
                    <th width="250">Tipo de Usuario</th>
                  </tr>
                </thead>

                <tbody>
                  <!-- Se crea un ciclo para que este imprimiendo en una tabla los datos de todos los tipos de usuarios registrados en la bd, obteniendo esos datos en el archivo de database_utilities -->
                  <?php
                      for ($i=0; $i < $total_users_type; $i++) 
                      {
                      ?>
                      <tr> 
                        <td><?php echo $type[$i]['id']?></td>
                        <td><?php echo $type[$i]['name'];?></td>
                      </tr>
                  <?php
                      }
                      ?>
                </tbody>

              </table>


              <br><br><br>
              <h2>Tabla de Status</h2>
              <br><br>  

              <table>
                
                <thead>
                  <tr>
                    <th width="200">ID</th>
                    <th width="250">Tipo de Status</th>
                  </tr>
                </thead>

                <tbody>
                  <!-- Se crea un ciclo para que este imprimiendo en una tabla los datos de todos los estados que puede tener un usuario registrado, obteniendo esos datos en el archivo de database_utilities -->
                  <?php
                      for ($i=0; $i < $total_status; $i++) 
                      {
                      ?>
                      <tr> 
                        <td><?php echo $status[$i]['id']?></td>
                        <td><?php echo $status[$i]['name'];?></td>
                      </tr>
                  <?php
                      }
                      ?>
                </tbody>

              </table>

             
            </div>
          </section>
        </div>
      </div>

    </div>
    

    <?php require_once('footer.php'); ?>

<!--Se crea la funcion en java script la cual manda una alerta que es para confirmar el que se elimine
algun registro de la base de datos-->
