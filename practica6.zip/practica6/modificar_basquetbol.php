<?php

  //Se manda llamar el archivo donde se tienen las funciones
  require_once('database_utilities_deportistas.php');


// Se guardan los datos a modificar del usuario en las variables correspondientes
  $id = isset( $_GET['id'] ) ? $_GET['id'] : '';

  //Se manda llamar la funcion de buscar por id, y trae el resultado de la funcion en una variable, en este caso
  // los datos del registro con el id que se selecciono
  $result = search_id_basquetbol($id); 

  if(isset($_POST["modificar"]))
  {

    if(isset($_POST["nombre"]))
    {
      $nombre = $_POST["nombre"];
    }

    if(isset($_POST["posicion"]))
    {
      $posicion = $_POST["posicion"];
    }

    if(isset($_POST["carrera"]))
    {
      $carrera = $_POST["carrera"];
    }

    if(isset($_POST["correo"]))
    {
      $correo = $_POST["correo"];
    }

    //se manda llamar la funcion de modificar, y se le da como parametros los datos del usuario

    update_basquetbol($id,$nombre,$posicion,$carrera,$correo);




    header("location: basquetbolistas.php");
  }


?>
<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso PHP |  Bienvenidos</title>
    <link rel="stylesheet" href="./css/foundation.css" />
    <script src="./js/vendor/modernizr.js"></script>
  </head>
  <body>
    
    <?php require_once('header.php'); ?>

     
    <div class="row">
 
    
      <div class="large-9 columns">
        <br><br>
        <h1>Modificar Usuario</h1>
        <br><br>
        <div class="section-container tabs" data-section>
          <section class="section">
            <div class="content" data-slug="panel1">
              <div class="row">
              </div>
              <form method="POST">
                <!--Se imprimen en los elementos los datos del registro seleccionado,traidos por la funcion buscar id-->
              <label>ID: </label>
              <input type="text" name="id" value="<?php echo $result[0]['id']?>" disabled>
              <br>  
              <label>Nombre: </label>
              <input type="text" name="nombre" value="<?php echo $result[0]['nombre']?>">
              <br>
              <label>Posicion: </label>
              <input type="text" name="posicion" value="<?php echo $result[0]['posicion']?>">
              <br>
              <label>Carrera: </label>
              <select name="carrera">
                <option><?php echo $result[0]['carrera']?></option>
                  <option value="ITI">Ingenieria en Tecnologias de la Informacion</option>
                  <option value="ITM">Ingenieria en Tecnologias de la Manufactura</option>
                  <option value="IM">Ingenieria en Mecatronica</option>
                  <option value="ISA">Ingenieria en Sistemas Automotrices</option>
                  <option value="PyMES">Licenciatura en Administracion y Gestion de PYMES</option>
              </select>
              <br><br>
              <label>Correo: </label>
              <input type="text" name="correo" value="<?php echo $result[0]['correo']?>">
              <br>
              <input type="submit" name="modificar" value="MODIFICAR" class="button" onclick="alertaEliminar();">
              </form>
            </div>
          </section>
        </div>
        
      </div>


          <script type="text/javascript">

      function alertaEliminar()
      {
        var msj = confirm("Desea aplicar las modificaciones?");
        if(msj == false)
        {
          event.preventDefault();
        }
      }
    </script>
    

    <?php require_once('footer.php'); ?>


