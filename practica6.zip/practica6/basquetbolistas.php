<?php

//se manda llamar el archivo donde se tienen las funciones
require_once('database_utilities_deportistas.php');

?>
<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso PHP |  Bienvenidos</title>
    <link rel="stylesheet" href="./css/foundation.css" />
    <script src="./js/vendor/modernizr.js"></script>
  </head>
  <body>
    
    <?php require_once('header.php'); ?>

     
    <div class="row">
 
      <div class="large-9 columns">
        <br><br><br>
        <h1>Basquetbolistas Registrados</h1>
        <br><br>
        <!-- Se crea un boton que permite ir al archivo de registrar usuario nuevo -->
          <a href="./registrar_basquetbol.php" class="button radius tiny" style="background-color: green; color: white;">Registrar Usuario</a>
          
        <div class="section-container tabs" data-section>
          <section class="section">
            <div class="content" data-slug="panel1">
              <div class="row">
              </div>
                <?php 
                    if($total_jugadores_b){ 
                ?>
                           
                      <table>
                        <thead>
                          <tr>
                            <th width="200">ID</th>
                            <th width="250">Nombre</th>
                            <th width="250">Posicion</th>
                            <th width="250">Carrera</th>
                            <th width="250">Correo</th>
                            <th width="250">Accion</th>

                          </tr>
                        </thead>
                        <tbody>
                        <?php
                        ///Mediante un ciclo se imprime todos los basquetbolistas registrados, junto con su informacion y con dos botones con la opcion de modificar o eliminar el futbolista seleccionado
                        for ($i=0; $i < $total_jugadores_b; $i++) 
                        { 
                          $id = $jugadores_b[$i]['id'];                        

                        ?>
                          <tr>
                            <td> <?php echo $jugadores_b[$i]['id'];?> </td>
                            <td> <?php echo $jugadores_b[$i]['nombre'];?> </td>
                            <td> <?php echo $jugadores_b[$i]['posicion'];?> </td>
                            <td> <?php echo $jugadores_b[$i]['carrera'];?> </td>
                            <td> <?php echo $jugadores_b[$i]['correo'];?> </td>
                            <td><a <?php echo "href='modificar_basquetbol.php?id=$id'"; ?> class="button radius tiny secondary" style = "background-color: blue; color: white;">Modificar</a>
                            <a <?php echo "href='eliminar_basquetbol.php?id=$id'"; ?> class="button radius tiny alert" onclick="alertaEliminar()">Eliminar</a></td>
                          </tr>
                            <?php
                                   
                                }
                            ?>
                                    <tr>
                                        <td colspan="4"><b>Total de registros: </b><?php echo $total_jugadores_b;?></td>
                                    </tr>
                                </tbody>
                            </table>

              <?php 
                  }else{
              ?>
              No hay registros
              <?php 
                  }
              ?>
            </div>
          </section>
        </div>
      </div>

    </div>
    

    <?php require_once('footer.php'); ?>

<!--Se crea la funcion en java script la cual manda una alerta que es para confirmar el que se elimine
algun registro de la base de datos-->
    <script type="text/javascript">

      function alertaEliminar()
      {
        var msj = confirm("Deseas eliminar este usuario?");
        if(msj == false)
        {
          event.preventDefault();
        }
      }
    </script>