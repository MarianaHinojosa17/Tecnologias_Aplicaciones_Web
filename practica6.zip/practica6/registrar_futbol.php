<?php

  //Se manda llamar el archivo donde se tienen las funciones
  require_once('database_utilities_deportistas.php');

  //Se almacenan en las variables correspondientes los datos del futbolista que se quiere registrar, tomandose de los campos que se llenaron 
  if(isset($_POST["guardar"]))
  {
    if(isset($_POST["id"])) 
    {
      $id =  $_POST["id"];
    }

    if(isset($_POST["nombre"]))
    {
      $nombre = $_POST["nombre"];
    }

    if(isset($_POST["posicion"]))
    {
      $posicion = $_POST["posicion"];
    }

    if(isset($_POST["carrera"]))
    {
      $carrera = $_POST["carrera"];
    }

    if(isset($_POST["correo"]))
    {
      $correo = $_POST["correo"];
    }

    //Se manda llamar la funcion de registrar y se le da como parametro los datos del futbolista que se ingresaron en los campos
    register_futbol($id,$nombre,$posicion,$carrera,$correo);


    //Cuando se registra un usuario, automaticamente se dirige a la tabla de los futbolistas registrados
    header("location: futbolistas.php");
  }


?>
<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Curso PHP |  Bienvenidos</title>
    <link rel="stylesheet" href="./css/foundation.css" />
    <script src="./js/vendor/modernizr.js"></script>
  </head>
  <body>
    
    <?php require_once('header.php'); ?>

     
    <div class="row">
 
    
      <div class="large-9 columns">
        <br><br>
        <h2>Registrar Futbolista</h2>
        <br><br>
        <div class="section-container tabs" data-section>
          <section class="section">
            <div class="content" data-slug="panel1">
              <div class="row">
              </div>
              <form method="POST">
              <label>ID:  </label>
              <input type="text" name="id">
              <br>
              <label>Nombre: </label>
              <input type="text" name="nombre">
              <br>
              <label>Posicion: </label>
              <input type="text" name="posicion">
              <br>
              <label>Carrera: </label>
              <select name="carrera">
                  <option value="ITI">Ingenieria en Tecnologias de la Informacion</option>
                  <option value="ITM">Ingenieria en Tecnologias de la Manufactura</option>
                  <option value="IM">Ingenieria en Mecatronica</option>
                  <option value="ISA">Ingenieria en Sistemas Automotrices</option>
                  <option value="PyMES">Licenciatura en Administracion y Gestion de PYMES</option>
              </select>
              <br><br>
              <label>Correo: </label>
              <input type="text" name="correo">
              <br>
              <input type="submit" name="guardar" value="Registrar Futbolista" class="button">
              </form>
            </div>
          </section>
        </div>
        
      </div>
    

    <?php require_once('footer.php'); ?>


