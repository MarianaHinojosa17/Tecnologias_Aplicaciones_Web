<?php

	//Se manda llamar el archivo donde se tiene la informacion de la base de datos para la conexion utilizando PDO
	require_once('database_credentials.php');

    
    //Total de usuario registrados
    //Se realiza la consulta necesaria para traer el numero total de usuarios registrados
    $query = "SELECT COUNT(*) as total_users FROM user";
    $statement = $pdo->prepare($query);
    $statement->execute();
    $results = $statement->fetchAll();
    $total_users = $results[0]['total_users'];

    //Total de tipos de usuarios
    //Se realiza la consulta necesaria para traer el numero total de los tipos de usuarios existentes
    $query = "SELECT COUNT(*) as total_users_type FROM user_type";
    $statement = $pdo->prepare($query);
    $statement->execute();
    $results = $statement->fetchAll();
    $total_users_type = $results[0]['total_users_type'];

    //Total de estados de un usuario
    //Se realiza la consulta necesaria para traer el numero total de los tipos de estados de un usuario registrado
    $query = "SELECT COUNT(*) as total_status FROM status";
    $statement = $pdo->prepare($query);
    $statement->execute();
    $results = $statement->fetchAll();
    $total_status = $results[0]['total_status'];

    //Total de inicio de sesiones
    //Se realiza la consulta necesaria para traer el numero total de los sesiones registradas en la tabla
    $query = "SELECT COUNT(*) as total_logged FROM user_log";
    $statement = $pdo->prepare($query);
    $statement->execute();
    $results = $statement->fetchAll();
    $total_logged = $results[0]['total_logged'];

     //Total de usuarios activos
    //Se realiza la consulta necesaria para traer el numero total de usuario registrados que se encuentran en estado activo
    $query = "SELECT COUNT(*) as total_active_users FROM user where status_id = 1";
    $statement = $pdo->prepare($query);
    $statement->execute();
    $results = $statement->fetchAll();
    $total_active_users = $results[0]['total_active_users'];

     //Total de usuarios inactivos
    //Se realiza la consulta necesaria para traer el numero total de usuarios registrados que se encuentran en estado inactivo
    $query = "SELECT COUNT(*) as total_inactive_users FROM user WHERE status_id = 2";
    $statement = $pdo->prepare($query);
    $statement->execute();
    $results = $statement->fetchAll();
    $total_inactive_users = $results[0]['total_inactive_users'];




    //Se realiza la consulta para traer toda la informacion de los usuarios
    $query = "SELECT *  FROM user";
    $statement = $pdo->prepare($query);
    $statement->execute();
    $user = $statement->fetchAll();

    //Se realiza la consulta para seleccionar el estado al que pertenece cada usuario basandose en su id, y guardando el nombre del estado
    $query = "SELECT s.name  FROM user as u INNER JOIN status as s WHERE u.status_id = s.id";
    $statement = $pdo->prepare($query);
    $statement->execute();
    $user_status = $statement->fetchAll();

    //Se realiza la consulta para seleccionar la sesion de cada usuario registrado en la bd, basandonos en el id del usuario
    $query = "SELECT u.email  FROM user as u INNER JOIN user_log as l WHERE u.id = l.user_id";
    $statement = $pdo->prepare($query);
    $statement->execute();
    $user_log = $statement->fetchAll();

    //Se realiza la consulta necesaria para seleccionar el tipo de usuario de cada usuario registrado en la bd, basandonos en el id del usuario
    $query = "SELECT t.name FROM user AS u INNER JOIN user_type AS t WHERE u.user_type_id = t.id";
    $statement = $pdo->prepare($query);
    $statement->execute();
    $user_type = $statement->fetchAll();



    //Se realiza la consulta para seleccionar toda la informacion de la tabla status
    $query = "SELECT *  FROM status";
    $statement = $pdo->prepare($query);
    $statement->execute();
    $status = $statement->fetchAll();



    //Se realiza la consulta para seleccionar toda la informacion de las sesiones
     $query = "SELECT *  FROM user_log";
    $statement = $pdo->prepare($query);
    $statement->execute();
    $log = $statement->fetchAll();
    


    //Se realiza la consulta para selecciona toda la informacion de la tabla de los tipos de usuarios
    $query = "SELECT *  FROM user_type";
    $statement = $pdo->prepare($query);
    $statement->execute();
    $type = $statement->fetchAll();
    






	
?>