<?php 

	//Se manda llamar el archivo donde se creo la conexion con la bd utilizando PDO
	require_once('database_credentials_deportistas.php');

	$result;

	//Funcion para eliminar un registro en la tabla de futbol, dando como paramentro los datos del futbolista que se agregaron en los campos
	function register_futbol($id,$nombre,$posicion,$carrera,$correo){
		global $pdo;
		$query = "INSERT INTO futbol (id,nombre,posicion,carrera,correo) VALUES ($id,'$nombre','$posicion','$carrera','$correo')";
		$statement = $pdo->prepare($query);
		$statement -> execute(); 
	}

	//Funcion para eliminar un resgistro de la tabla futbol, recibiendo como parameteo el id del futbolista
	function delete_futbol($id){
		global $pdo;
		$query = "DELETE FROM futbol WHERE id = $id ";
		$statement = $pdo->prepare($query);
		$statement -> execute();
	}

	//Funcion para buscar la informacion de algun futbolista en especial, dando su id
	function search_id_futbol($id){
		global $pdo,$result;
		$query = "SELECT * FROM futbol WHERE id = $id";
		$statement = $pdo->prepare($query);
		$statement -> execute();
		$result = $statement->fetchAll();
		return $result;
	}

	//Funcion para actualizar algun registro de la tabla futbolista, dando como para el id del futbolista a regustrar y sus campos que se quieren modificar
	function update_futbol($id,$nombre,$posicion,$carrera,$correo){
		global $pdo;
		$query = "UPDATE futbol SET nombre = '$nombre', posicion = '$posicion', carrera ='$carrera', correo = '$correo' WHERE id =$id";
		$statement = $pdo->prepare($query);
		$statement -> execute();
	}




	//SE REALIZAN LAS MISMAS FUNCIONES PERO AHORA TODO BASADO EN LA TABLA DE BASQUETBOL, LA FUNCION PARA REGISTRAR, LA FUNCION PARA ELIMINAR, PARA BUSCAR, PARA MODIFICAR.
	//ES EXACTAMENTE LOS MISMO, CON LOS MISMOS CAMPOS PERO EN LA TABLA BASQUETBOL

	function register_basquetbol($id,$nombre,$posicion,$carrera,$correo){
		global $pdo;
		$query = "INSERT INTO basquetbol (id,nombre,posicion,carrera,correo) VALUES ($id,'$nombre','$posicion','$carrera','$correo')";
		$statement = $pdo->prepare($query);
		$statement -> execute(); 
	}

	function delete_basquetbol($id){
		global $pdo;
		$query = "DELETE FROM basquetbol WHERE id = $id ";
		$statement = $pdo->prepare($query);
		$statement -> execute();
	}
	
	function search_id_basquetbol($id){
		global $pdo,$result;
		$query = "SELECT * FROM basquetbol WHERE id = $id";
		$statement = $pdo->prepare($query);
		$statement -> execute();
		$result = $statement->fetchAll();
		return $result;
	}

	function update_basquetbol($id,$nombre,$posicion,$carrera,$correo){
		global $pdo;
		$query = "UPDATE basquetbol SET nombre = '$nombre', posicion = '$posicion', carrera ='$carrera', correo = '$correo' WHERE id =$id";
		$statement = $pdo->prepare($query);
		$statement -> execute();
	}



	//Se realiza la consulta para contal el total de basquetbolistas registrados
    $query2 = "SELECT COUNT(*) as jugadores_b FROM basquetbol";
    $statement2 = $pdo->prepare($query2);
    $statement2->execute();
    $results2 = $statement2->fetchAll();
    $total_jugadores_b = $results2[0]['jugadores_b'];

    //Se realiza la consulta para seleccionar toda la informacion de los basquetbolistas registrados
    $query2 = "SELECT * FROM basquetbol";
    $statement2 = $pdo->prepare($query2);
    $statement2->execute();
    $jugadores_b = $statement2->fetchAll();
    

	//Se realiza la consulta para contal el total de futbolistas registrados
	$query = "SELECT COUNT(*) as jugadores FROM futbol";
    $statement = $pdo->prepare($query);
    $statement->execute();
    $results = $statement->fetchAll();
    $total_jugadores = $results[0]['jugadores'];

    //Se realiza la consulta para seleccionar toda la informacion de los futbolistas registrados
    $query = "SELECT * FROM futbol";
    $statement = $pdo->prepare($query);
    $statement->execute();
    $jugadores = $statement->fetchAll();





 ?>